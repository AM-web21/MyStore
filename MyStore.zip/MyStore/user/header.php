<?php
session_start(); // Ensure session starts before checking
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Panel</title>
    <!-- Bootstrap Cdn  -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- font awesome icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <?php
    
    $count = 0;
    if(isset($_SESSION['cart'])){
        $count = count($_SESSION['cart']);
        

    }
    ?>
    <!-- navbar  -->
    <nav class="navbar navbar-light bg-light">
        <div class="container-fluid font-monospace">
            <a class="navbar-brand pb-2"><img src="Logoimg.png" width="150px" alt=""></a>
            
            <div class="d-flex ">
            <a href="index.php" class=" text-warning text-decoration-none pe-2"> <i class="fas fa-home"></i> Home</a>
            <a href="" class=" text-warning text-decoration-none pe-2"> <i class="fas fa-shopping-cart"></i> Cart(<?php echo $count ?>) |</a>
            <span class="text-warning pe-2"> 
                <i class="fa fa-user-shield"></i>Hello,
                <?php 
                if(isset($_SESSION['user'])){
                echo $_SESSION['user']; 
                echo "
               | <a href='form/logout.php' class='text-warning text-decoration-none pe-2'> <i class='fas fa-sign-in-alt'> </i> Logout |</a>
                
                ";
                }
                else{
                    
                    echo "
               | <a href='form/login.php' class='text-warning text-decoration-none pe-2'> <i class='fas fa-sign-in-alt'> </i> Login |</a>
                
                ";
                }
                ?>
                    

                <a href="../admin/mystore.php" class=" text-warning text-decoration-none pe-2">Admin</a>
            </span>
        </div>
        </div>

    </nav>

    <div class="bg-danger sticky-top font-monospace ">
        <ul class="list-unstyled d-flex justify-content-center">
            <li><a href="laptop.php" class="text-decoration-none text-white fw-bold fs-4 px-5">LAPTOPS</a></li>
            <li><a href="mobile.php" class="text-decoration-none text-white fw-bold fs-4 px-5">MOBILES</a></li>
            <li><a href="bag.php" class="text-decoration-none text-white fw-bold fs-4 px-5">BAGS</a></li>
        </ul>
    </div>
    <!-- navbar  -->


</body>

</html>