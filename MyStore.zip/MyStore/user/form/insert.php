

<?php
include 'connection.php';
if(isset($_POST['submit']))
{
    $name = $_POST['name'];
    $email = $_POST['email'];
    $number = $_POST['number'];
    $password = $_POST['password'];

    $dup_email = mysqli_query( $con,"SELECT * FROM `user` WHERE email = '$email'");
            $dup_username = mysqli_query( $con,"SELECT * FROM `user` WHERE username = '$name'");
            if(mysqli_num_rows($dup_email) )
            {
                echo "
                <script>
                alert('Email already exists');
                window.location.href='register.php';
                </script>
                                ";
                }
                
           
                if(mysqli_num_rows($dup_username) )
                {
                    echo "
                    <script>
                    alert('Username already exists');
                    window.location.href='register.php';
                    </script>
                                    ";
                    }
                    else{
                        $sql="insert into user (username,email,number,password)
                        VALUES ('$name','$email','$number','$password')";
                        $result = mysqli_query($con,$sql);
                        if($result){
                            echo "<script>
                    alert('Register Successfully');
                    window.location.href='login.php';
                    </script>";
                    
                            }
                            else {
                                die(mysqli_error($con));
                                } 
                    }


}
?>