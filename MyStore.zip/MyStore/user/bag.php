<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page Card</title>
    <?php
    include 'header.php';
    ?>
</head>

<body>
    <div class="container-fluid">
        <div class="colmd-12">
            <div class="row">

           
    <h1 class="text-warning font-monospace my-3 text-center">BAG</h1>
    <?php
    include 'config.php';
    $query = "SELECT * FROM  product";
    $result = mysqli_query($con, $query);
    while ($row = mysqli_fetch_array($result)) {

        $check_page =$row['category'];
        if ($check_page === "bag") {



        echo "
        <div class='col-md-6 col-lg-4 m-auto mb-3'>
<div class='card m-auto' style='width: 18rem;'>
    <img src='../admin/product/$row[image]' class='card-img-top m-auto' >
    <div class='card-body text-center'>
        <h5 class='card-title text-danger fs-4 fw-bold'>$row[name]</h5>
        <p class='card-text text-danger fs-4 fw-bold'> ";?>Rs: <?php echo number_format($row['price'],2) ?> <?php echo "  </p>
         <form method='POST' action='insertcart.php'>
                                        <input type='hidden' name='name' value='$row[name]'>
                                        <input type='hidden' name='price' value='$row[price]'>
                                        <input type='number' name='quantity' min='1' max='20' value='1' required> <br><br>
                                        <input type='submit' name='addcart' class='btn btn-danger text-white w-100' value='Add to Cart'>
                                    </form>
    </div>
</div>
</div>
";
    }
}
    ?>
     </div>
        </div>
    </div>
    <?php
    include 'footer.php';
    ?>
</body>

</html>