



<?php

$con = new mysqli('localhost', 'root', '', 'ecommerce');

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

$adminname = mysqli_real_escape_string($con, $_POST['username']);
$adminpassword = mysqli_real_escape_string($con, $_POST['userpassword']);

$result = mysqli_query($con, "SELECT * FROM `admin` WHERE username = '$adminname' AND userpassword = '$adminpassword'");
session_start();
if (mysqli_num_rows($result)) {
    $_SESSION['admin'] = $adminname;
    echo "<script>
        alert('Login Successful');
        window.location.href = '/MyStore/admin/mystore.php';
        
    </script>";
} else {
    echo "<script>
         alert('Invalid Username or Password');
         window.location.href='/MyStore/admin/form/login.php';
        </script>";
}
?>

