<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>MyStore Dashboard</title>
  <!-- Bootstrap Cdn  -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <!-- owl carousel cdn 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" referrerpolicy="no-referrer" /> -->
  <!-- font awesome icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<?php
//  session_start();
//  if(!$_SESSION['admin'] ){
//   header('location:\MyStore\admin\form\login.php');

//  }

// session_start();
// if (!isset($_SESSION['username'])) {
//     header("Location: /MyStore/admin/form/login.php");
//     exit();
// }


// session_start();

// // Check if session is set
// if (!isset($_SESSION['username'])) {
//     header("Location: /MyStore/admin/form/login.php");
//     exit();
// }


session_start();

// Prevent back button from showing cached page after logout
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Sat, 01 Jan 2000 00:00:00 GMT");

// Redirect if session is not set
if (!$_SESSION['admin']) {
  header("Location: form/login.php");
  exit();
}





?>


<body>
  <!-- navbar  -->
  <nav class="navbar bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand text-white">MyStore</a>
      <span class="text-white">
        <i class="fa-solid fa-user-shield"></i>
        Hello, <?php echo $_SESSION['admin'];  ?> |
        <i class="fa-solid fa-right-from-bracket"></i>
        <a href="form/logout.php" class="text-decoration-none text-white">Logout</a>
        |
        <a href="#" class="text-decoration-none text-white">UserPanel</a>
      </span>
    </div>
  </nav>

  <!-- navbar  -->
  <div>
    <h2 class="text-center">Dashbord</h2>
  </div>

  <div class=" col-md-6 text-center bg-danger m-auto">
    <a href="product/index.php" class="text-white text-decoration-none fs-4 fw-bold px-5">Add Post</a>
    <a href="user.php" class="text-white text-decoration-none fs-4 fw-bold px-5">Users</a>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>