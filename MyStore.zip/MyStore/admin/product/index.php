<?php
include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Home Page</title>
    <!-- Bootstrap Cdn  -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col-md-6 m-auto border border-primary mt-3">

                <form action="insert.php" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <p class="text-center fw-bold fs-3 text-warning">Product Detail: </p>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Product Name:</label>
                        <input type="text" name="name" class="form-control" placeholder="Enter Product Name">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Product Price:</label>
                        <input type="text" name="price" class="form-control" placeholder="Enter Product Price">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Add Product Image:</label>
                        <input type="file" name="image" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Select Page Category</label>
                        <select class="form-select" name="pages">
                            <option value="home">Home</option>
                            <option value="laptop">Laptop</option>
                            <option value="bag">Bag</option>
                            <option value="mobile">Mobile</option>
                        </select>
                    </div>
                    <button name="submit" class="bg-danger fw-bold fs-4 my-3 form-control text-white">Upload</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Fetch Data  -->
     <div class="container my-5 col-md-8 m-auto border ">
    <table class="table border border-warning " >
        <thead  class="  fs-5 text-center" >
            <tr >
                <th class=" bg-dark text-white " scope="col">ID </th>
                <th class=" bg-dark text-white " scope="col">Name </th>
                <th class=" bg-dark text-white " scope="col">Price</th>
                <th class=" bg-dark text-white " scope="col">Image</th>
                <th class=" bg-dark text-white " scope="col">Category</th>
                <th class=" bg-dark text-white " scope="col">Update</th>
                <th class=" bg-dark text-white " scope="col">Delete</th>
            </tr>
        </thead>
        <tbody class="text-center">

            <?php
            $sql = "SELECT * FROM  product";
            $result = mysqli_query($con, $sql);
            if ($result) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $id = $row['id'];
                    $name = $row['name'];
                    $price = $row['price'];
                    $image = $row['image'];
                    $category = $row['category'];
                    echo '<tr>
      <th scope="row">' . $id . '</th>
      <td>' . $name . '</td>
      <td>' . $price. '</td>
      <td><img src="' . $image . '" width="100" height="100"></td>
      <td>' . $category. '</td>


      <td>
    <button class = "btn btn-primary"><a href="update.php? updateid=' . $id . '" class="text-light"> Update</a></button>
</td>
      <td>
    <button class = "btn btn-danger"><a href="delete.php? deleteid=' . $id . '" class="text-light"   > Delete</a></button>
</td>
    </tr>';
                }
            }

            ?>


        </tbody>
    </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>