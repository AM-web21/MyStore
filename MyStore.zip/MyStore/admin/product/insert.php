

<?php
// include 'connection.php';
// if(isset($_POST['submit'])){
//     $name = $_POST['name'];
//     $price = $_POST['price'];
//     $image = $_FILES['image'];
//     // print_r($image);
//     $imagelocation = $_FILES['image'] ['tmp_name'] ;    //these instruction is for upload image 
//     $imagename = $_FILES['image'] ['name'] ;
    
//     $imagedestination = "uploadimage/".$imagename;
//     move_uploaded_file($imagelocation,$imagedestination);

//     $category = $_POST['pages'];

//     // insert product query 
//     $query = "INSERT INTO product (name,price,image,category) VALUES ('$name','$price','$imagedestination','$category')";
//     $result = mysqli_query($con,$query);
    
//     if ($result) {
//         header('location:index.php');
//     } else {
//         die(mysqli_error($con));
//     }
// }
   
?>

<?php
include 'connection.php';

if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $price = floatval($_POST['price']); // Convert price to a float
    $formatted_price = number_format($price, 2, '.', ''); // Format price with two decimal places

    $image = $_FILES['image'];
    
    $imagelocation = $_FILES['image']['tmp_name'];    
    $imagename = $_FILES['image']['name'];
    
    $imagedestination = "uploadimage/" . $imagename;
    move_uploaded_file($imagelocation, $imagedestination);

    $category = $_POST['pages'];

    // Insert product query with formatted price
    $query = "INSERT INTO product (name, price, image, category) VALUES ('$name', '$formatted_price', '$imagedestination', '$category')";
    $result = mysqli_query($con, $query);
    
    if ($result) {
        header('location:index.php');
    } else {
        die(mysqli_error($con));
    }
}
?>

               
              